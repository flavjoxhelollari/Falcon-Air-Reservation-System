﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tickets
{
    public class Ticket

    {
        private Flight flight;
        private int number;
        private string type;
        Passenger passenger;
        private DateTime date;
        private int seatNumber;
        private char seatAlignment;

        public Ticket()
        {



        }

        public Ticket(Flight flight, int number, string type, Passenger passenger, DateTime date, int seat, char alignment)
        {
            this.flight = flight;
            this.number = number;
            this.type = type;
            this.passenger = passenger;
            this.date = date;
            this.seatNumber = seat;
            this.seatAlignment = alignment;
        }

        public Flight Flight
        {
            get
            {
                return this.flight;
            }

            set
            {
                this.flight = value;
            }
        }
        public int Number
        {
            get
            {
                return this.number;
            }

            set
            {
                this.number = value;
            }
        }
        public string Type
        {
            get
            {
                return this.type;
            }

            set
            {
                type = value;
            }
        }

        public Passenger Passenger
        {
            get
            {
                return this.passenger;
            }

            set
            {
                passenger = value;
            }
        }


        public DateTime Date
        {
            get
            {
                return this.date;
            }

            set
            {
                date = value;
            }
        }

        public int SeatNumber
        {
            get
            {
                return this.seatNumber;
            }

            set
            {
                seatNumber = value;
            }
        }

        public char SeatAlignment
        {
            get
            {
                return this.seatAlignment;
            }

            set
            {
                seatAlignment = value;
            }
        }

        public string DisplayInfo()
        {
            string info = "Ticket Number: " + this.number + "\n"
                + "Type: " + this.type + "\n" + "Name: " + this.passenger.FirstName + "\n" + "Surname : " + this.passenger.LastName + "\n"
                + "Date: " + this.date.ToString() + "\n" + "Seat: " + this.SeatNumber + this.seatAlignment
                +   this.flight.TakeOff + "\n" + this.flight.Landing;

            return info;
        }

    }

    public class Passenger
    {
        private string firstName;
        private string lastName;

        public Passenger()
        {
            
        }

        public Passenger(string firstName, string lastName)
        {
            this.firstName = firstName;
            this.lastName = lastName;
        }

        public string FirstName
        {
            get
            {
                return this.firstName;
            }

            set
            {
                this.firstName = value;
            }

        }

        public string LastName
        {
            get
            {
                return this.lastName;
            }

            set
            {
                this.lastName = value;
            }
        }

    }


    public class Flight
    {
        private string flightID;
        private string takeOff;
        private string landing;
        private string stopover;
        private string airlineType;
        private int maxPassengers;
        private int rows;
        private bool eatingOnBoard;
        private DateTime takeOffDate;
        private DateTime landingDate;

        public Flight()
        { }

        public Flight(string ID, string takeOff, string landing, string stopover, string airlineType,
            int passengers, int rows, bool eatingOnBoard, DateTime takeOffDate, DateTime landingDate)
        {
            this.flightID = ID;
            this.takeOff = takeOff;
            this.landing = landing;
            this.stopover = stopover;
            this.airlineType = airlineType;
            this.maxPassengers = passengers;
            this.rows = rows;
            this.eatingOnBoard = eatingOnBoard;
            this.takeOffDate = takeOffDate;
            this.landingDate = landingDate;
        }

        public string FlightID
        {
            get
            {
                return this.flightID;
            }
            set
            {
                this.flightID = value;
            }
           

            
        }

        public string TakeOff
        {
           
            get
            {
                return this.takeOff;
            }
            set
            {
                this.takeOff = value;
            }

        }

        public string Landing
        {
           
            get
            {
                return this.landing;
            }
            set
            {
                this.landing = value;
            }

        }

        public string Stopover
        {
            
            get
            {
                return this.stopover;
            }
            set
            {
                this.stopover = value;
            }

        }

        public string AirlineType
        {
            
            get
            {
                return this.airlineType;
            }

            set
            {
                this.airlineType = value;
            }
        }

        public int Passengers
        { 
            
            get
            {
                return this.maxPassengers;
            }

            set
            {
                this.maxPassengers = value;
            }

        }

        public int Rows
        {
            
            get
            {
                return this.rows;
            }

            set
            {
                this.rows = value;
            }
        }

        public bool EatingOnBoard
        {
            get
            {
                return this.eatingOnBoard;
            }

            set
            {
                this.eatingOnBoard = value;
            }
        }

        public DateTime TakeOffDate
        {
           
            get
            {
                return this.takeOffDate;
            }
            set
            {
                this.takeOffDate = value;
            }

        }

        public DateTime LandingDate
        {

            get
            {
                return this.landingDate;
            }

            set { 
                this.landingDate = value; 
            }

        }

        public string DisplayInfo()
        {
            string info = "Flight ID: " + this.flightID + "\n" + "Takeoff from: " + this.takeOff + "\n" +
                "Landing to: " + this.landing + "\n" + "Stopover in:  " + this.stopover + "\n" +
                "Airline type: " + this.airlineType + "\n" + "Maximum number of passengers: " + this.maxPassengers + "\n"
                + "Number of rows: " + this.rows + "\n" + "Takeoff date: " + this.takeOffDate.ToString() + "\n" +
                "Landing date: " + this.landingDate.ToString() + "\n" + "Eating on board: " + this.eatingOnBoard.ToString();

            return info;
        }

    }
}
